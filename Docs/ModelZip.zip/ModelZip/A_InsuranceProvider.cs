﻿namespace MVAManagement.Models.MVA
{
    public class A_InsuranceProvider
    {
        public int Id { get; set; }
        public string ProviderName { get; set; } = null!; // Refactored from Name
        public string? ProviderCode { get; set; } // Refactored from Code

        // Navigation Properties
        public virtual ICollection<A_VehicleDetail> InsuredVehicles { get; set; } = new List<A_VehicleDetail>();
    }
}
