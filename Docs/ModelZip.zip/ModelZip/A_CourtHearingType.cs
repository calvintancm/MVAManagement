﻿namespace MVAManagement.Models.MVA
{
    public class A_CourtHearingType
    {
        public int Id { get; set; }
        public string Code { get; set; } = null!; // e.g., "M", "H"
        public string Description { get; set; } = null!; // Refactored from Desc

        // Navigation Property
        public virtual ICollection<A_LegalCase> LegalCases { get; set; } = new List<A_LegalCase>();
    }
}
